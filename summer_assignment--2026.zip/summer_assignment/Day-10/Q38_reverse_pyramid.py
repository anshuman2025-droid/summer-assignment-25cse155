# Q38 - Print reverse pyramid
n = int(input("Enter rows: "))
for i in range(n, 0, -1):
    print(' ' * (n - i) + '*' * (2 * i - 1))